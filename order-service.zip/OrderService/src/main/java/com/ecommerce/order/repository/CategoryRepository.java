package com.ecommerce.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecommerce.order.dto.SearchDTO;
import com.ecommerce.order.model.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long>
{
	@Query("select new com.ecommerce.order.dto.SearchDTO(catgry.categoryName,catgry.categoryDescription,pro.productId,pro.productName,pro.productPrice,pro.productQuantity) from "
			+ "Category catgry join catgry.prodList  pro on  catgry.categoryId = pro.category.categoryId and "
			+ " (pro.productName=:productName or catgry.categoryName=:catgryName)")
	List<SearchDTO> getCategoryProductList(String catgryName, String productName);
}
