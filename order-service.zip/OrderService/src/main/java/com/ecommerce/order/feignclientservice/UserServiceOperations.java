package com.ecommerce.order.feignclientservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ecommerce.order.dto.UserDTO;
import com.ecommerce.order.exception.ResourceNotFoundException;

@FeignClient(name="http://USER-SERVICE:9001/users")
public interface UserServiceOperations 
{
	@GetMapping("/userName")
	public ResponseEntity<UserDTO> getUserDetails(@PathVariable("userName") String userName) throws ResourceNotFoundException; 
}
