package com.ecommerce.order.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.ecommerce.order.dto.CartDTO;
import com.ecommerce.order.dto.CartDetailsDTO;
import com.ecommerce.order.dto.OrderHistoryDTO;
import com.ecommerce.order.dto.OrderProductDTO;

public interface OrderService
{
	String orderProducts(OrderProductDTO orderProdDto);
    List<OrderHistoryDTO> getOrderHistory(String userName,String userId);
	ResponseEntity<String> saveCartDetails(String userId, List<CartDTO> cartDto);
	ResponseEntity<List<CartDetailsDTO>> getCartDetails(String userId,String cartId);
}
