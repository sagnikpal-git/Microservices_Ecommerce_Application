package com.ecommerce.order.service;

import java.util.List;

import com.ecommerce.order.dto.SearchDTO;

public interface SearchService 
{
	List<SearchDTO> findProductDetails(String productName, String catName);
}
